
  # Flask API Development

  This is a code bundle for Flask API Development. The original project is available at https://www.figma.com/design/ayAxdqNZSMR0HB2Igpti9C/Flask-API-Development.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  