import React, { useState } from 'react';
import { CompanyInfoSection } from './components/CompanyInfoSection';
import { StockMarketDataSection } from './components/StockMarketDataSection';
import { HistoricalDataSection } from './components/HistoricalDataSection';
import { AnalyticalInsightsSection } from './components/AnalyticalInsightsSection';
import { Card } from './components/ui/card';
import { Input } from './components/ui/input';
import { Button } from './components/ui/button';
import { Search, TrendingUp } from 'lucide-react';

export default function App() {
  const [symbol, setSymbol] = useState('AAPL');
  const [searchInput, setSearchInput] = useState('AAPL');

  const handleSearch = () => {
    if (searchInput.trim()) {
      setSymbol(searchInput.toUpperCase());
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-blue-600 p-2 rounded-lg">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-slate-900">Stock Market Analytics Dashboard</h1>
                <p className="text-slate-600 text-sm">Real-time company data and market insights</p>
              </div>
            </div>
          </div>
          
          {/* Search Bar */}
          <div className="mt-6 flex gap-2 max-w-md">
            <Input
              type="text"
              placeholder="Enter company symbol (e.g., AAPL, GOOGL, MSFT)"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value.toUpperCase())}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              className="flex-1"
            />
            <Button onClick={handleSearch} className="bg-blue-600 hover:bg-blue-700">
              <Search className="w-4 h-4 mr-2" />
              Search
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {/* Company Information */}
          <CompanyInfoSection symbol={symbol} />
          
          {/* Stock Market Data */}
          <StockMarketDataSection symbol={symbol} />
          
          {/* Historical Market Data */}
          <HistoricalDataSection symbol={symbol} />
          
          {/* Analytical Insights */}
          <AnalyticalInsightsSection symbol={symbol} />
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <p className="text-center text-slate-600 text-sm">
            Stock Market Analytics Dashboard - Data sourced from Yahoo Finance API
          </p>
        </div>
      </footer>
    </div>
  );
}
