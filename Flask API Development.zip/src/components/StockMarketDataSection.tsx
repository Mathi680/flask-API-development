import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { TrendingUp, TrendingDown, Activity, DollarSign, BarChart3, Clock } from 'lucide-react';

interface StockMarketDataProps {
  symbol: string;
}

// Mock data representing Flask API endpoint response
const getStockMarketData = (symbol: string) => {
  const stockData: Record<string, any> = {
    AAPL: {
      symbol: 'AAPL',
      marketState: 'OPEN',
      currentPrice: 178.45,
      priceChange: 2.35,
      percentageChange: 1.33,
      dayHigh: 179.20,
      dayLow: 176.80,
      volume: '52,847,392',
      marketCap: '2.78T',
      previousClose: 176.10,
    },
    GOOGL: {
      symbol: 'GOOGL',
      marketState: 'OPEN',
      currentPrice: 141.25,
      priceChange: -1.15,
      percentageChange: -0.81,
      dayHigh: 143.10,
      dayLow: 140.85,
      volume: '21,342,567',
      marketCap: '1.76T',
      previousClose: 142.40,
    },
    MSFT: {
      symbol: 'MSFT',
      marketState: 'OPEN',
      currentPrice: 374.85,
      priceChange: 5.20,
      percentageChange: 1.41,
      dayHigh: 376.50,
      dayLow: 371.30,
      volume: '18,943,821',
      marketCap: '2.79T',
      previousClose: 369.65,
    },
  };

  return stockData[symbol] || stockData.AAPL;
};

export function StockMarketDataSection({ symbol }: StockMarketDataProps) {
  const stockData = getStockMarketData(symbol);
  const isPositive = stockData.priceChange >= 0;

  return (
    <Card className="p-6 bg-white shadow-sm">
      <div className="flex items-center gap-2 mb-4">
        <Activity className="w-5 h-5 text-blue-600" />
        <h2 className="text-slate-900">Real-Time Stock Market Data</h2>
        <Badge 
          className={`ml-auto ${stockData.marketState === 'OPEN' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}
        >
          <Clock className="w-3 h-3 mr-1" />
          {stockData.marketState}
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Current Price */}
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4 border border-blue-200">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="w-4 h-4 text-blue-700" />
            <p className="text-blue-900 text-sm">Current Price</p>
          </div>
          <p className="text-blue-900 text-2xl">${stockData.currentPrice.toFixed(2)}</p>
          <div className={`flex items-center gap-1 mt-1 ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
            {isPositive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
            <span className="text-sm">
              {isPositive ? '+' : ''}{stockData.priceChange.toFixed(2)} ({isPositive ? '+' : ''}{stockData.percentageChange.toFixed(2)}%)
            </span>
          </div>
        </div>

        {/* Day Range */}
        <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
          <div className="flex items-center gap-2 mb-2">
            <BarChart3 className="w-4 h-4 text-slate-700" />
            <p className="text-slate-900 text-sm">Day Range</p>
          </div>
          <p className="text-slate-900">
            ${stockData.dayLow.toFixed(2)} - ${stockData.dayHigh.toFixed(2)}
          </p>
          <p className="text-slate-600 text-sm mt-1">Previous Close: ${stockData.previousClose.toFixed(2)}</p>
        </div>

        {/* Volume */}
        <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-4 h-4 text-slate-700" />
            <p className="text-slate-900 text-sm">Volume</p>
          </div>
          <p className="text-slate-900 text-xl">{stockData.volume}</p>
          <p className="text-slate-600 text-sm mt-1">shares traded</p>
        </div>

        {/* Market Cap */}
        <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="w-4 h-4 text-slate-700" />
            <p className="text-slate-900 text-sm">Market Cap</p>
          </div>
          <p className="text-slate-900 text-xl">${stockData.marketCap}</p>
          <p className="text-slate-600 text-sm mt-1">total value</p>
        </div>
      </div>
    </Card>
  );
}
