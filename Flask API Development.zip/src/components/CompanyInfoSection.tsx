import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Building2, Users, Briefcase } from 'lucide-react';

interface CompanyInfoProps {
  symbol: string;
}

// Mock data representing Flask API endpoint response
const getCompanyInfo = (symbol: string) => {
  const companyData: Record<string, any> = {
    AAPL: {
      symbol: 'AAPL',
      fullName: 'Apple Inc.',
      industry: 'Consumer Electronics',
      sector: 'Technology',
      summary: 'Apple Inc. designs, manufactures, and markets smartphones, personal computers, tablets, wearables, and accessories worldwide. The company offers iPhone, Mac, iPad, and Wearables, Home and Accessories products.',
      officers: [
        { name: 'Timothy D. Cook', title: 'Chief Executive Officer' },
        { name: 'Luca Maestri', title: 'Chief Financial Officer' },
        { name: 'Katherine L. Adams', title: 'General Counsel' },
        { name: 'Deirdre O\'Brien', title: 'Senior Vice President, Retail' },
      ],
    },
    GOOGL: {
      symbol: 'GOOGL',
      fullName: 'Alphabet Inc.',
      industry: 'Internet Content & Information',
      sector: 'Communication Services',
      summary: 'Alphabet Inc. offers various products and platforms in the United States, Europe, the Middle East, Africa, the Asia-Pacific, Canada, and Latin America. It operates through Google Services, Google Cloud, and Other Bets segments.',
      officers: [
        { name: 'Sundar Pichai', title: 'Chief Executive Officer' },
        { name: 'Ruth Porat', title: 'Chief Financial Officer' },
        { name: 'Prabhakar Raghavan', title: 'Senior Vice President' },
        { name: 'Philipp Schindler', title: 'Chief Business Officer' },
      ],
    },
    MSFT: {
      symbol: 'MSFT',
      fullName: 'Microsoft Corporation',
      industry: 'Software - Infrastructure',
      sector: 'Technology',
      summary: 'Microsoft Corporation develops, licenses, and supports software, services, devices, and solutions worldwide. The company operates in Productivity and Business Processes, Intelligent Cloud, and More Personal Computing segments.',
      officers: [
        { name: 'Satya Nadella', title: 'Chief Executive Officer' },
        { name: 'Amy E. Hood', title: 'Chief Financial Officer' },
        { name: 'Bradford L. Smith', title: 'President & Vice Chair' },
        { name: 'Judson Althoff', title: 'Chief Commercial Officer' },
      ],
    },
  };

  return companyData[symbol] || companyData.AAPL;
};

export function CompanyInfoSection({ symbol }: CompanyInfoProps) {
  const companyInfo = getCompanyInfo(symbol);

  return (
    <Card className="p-6 bg-white shadow-sm">
      <div className="flex items-center gap-2 mb-4">
        <Building2 className="w-5 h-5 text-blue-600" />
        <h2 className="text-slate-900">Company Information</h2>
        <Badge variant="outline" className="ml-auto">{companyInfo.symbol}</Badge>
      </div>
      
      <div className="space-y-4">
        <div>
          <h3 className="text-slate-900 mb-1">{companyInfo.fullName}</h3>
          <div className="flex gap-2 mb-3">
            <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">
              <Briefcase className="w-3 h-3 mr-1" />
              {companyInfo.sector}
            </Badge>
            <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
              {companyInfo.industry}
            </Badge>
          </div>
          <p className="text-slate-600">{companyInfo.summary}</p>
        </div>

        <div>
          <div className="flex items-center gap-2 mb-3">
            <Users className="w-4 h-4 text-slate-600" />
            <h4 className="text-slate-900">Key Officers</h4>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {companyInfo.officers.map((officer: any, index: number) => (
              <div key={index} className="bg-slate-50 rounded-lg p-3 border border-slate-200">
                <p className="text-slate-900">{officer.name}</p>
                <p className="text-slate-600 text-sm">{officer.title}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
}
