import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Lightbulb, TrendingUp, TrendingDown, AlertCircle, CheckCircle2, BarChart } from 'lucide-react';

interface AnalyticalInsightsProps {
  symbol: string;
}

// Mock data representing Flask API endpoint response
const getAnalyticalInsights = (symbol: string) => {
  const insights: Record<string, any> = {
    AAPL: {
      symbol: 'AAPL',
      sentiment: 'BULLISH',
      sentimentScore: 78,
      recommendation: 'BUY',
      technicalIndicators: {
        rsi: 62,
        macd: 'Positive',
        movingAverage: 'Above 50-day MA',
      },
      keyInsights: [
        {
          type: 'positive',
          title: 'Strong Upward Momentum',
          description: 'The stock has shown consistent growth over the past 30 days with a 12.5% increase.',
        },
        {
          type: 'positive',
          title: 'High Trading Volume',
          description: 'Above-average trading volume indicates strong investor interest and liquidity.',
        },
        {
          type: 'warning',
          title: 'Approaching Resistance Level',
          description: 'The stock is nearing a key resistance level at $180. Watch for potential consolidation.',
        },
        {
          type: 'neutral',
          title: 'Market Cap Leadership',
          description: 'Maintains position as one of the largest companies by market capitalization.',
        },
      ],
      priceTargets: {
        low: 165,
        average: 185,
        high: 205,
      },
      riskLevel: 'MODERATE',
    },
    GOOGL: {
      symbol: 'GOOGL',
      sentiment: 'NEUTRAL',
      sentimentScore: 55,
      recommendation: 'HOLD',
      technicalIndicators: {
        rsi: 48,
        macd: 'Neutral',
        movingAverage: 'Near 50-day MA',
      },
      keyInsights: [
        {
          type: 'neutral',
          title: 'Sideways Trading Pattern',
          description: 'The stock has been trading in a range with no clear directional trend.',
        },
        {
          type: 'positive',
          title: 'Strong Fundamentals',
          description: 'Company fundamentals remain solid with consistent revenue growth.',
        },
        {
          type: 'warning',
          title: 'Regulatory Concerns',
          description: 'Ongoing regulatory scrutiny may impact future performance.',
        },
        {
          type: 'neutral',
          title: 'AI Investment Focus',
          description: 'Significant investment in AI technology could drive future growth.',
        },
      ],
      priceTargets: {
        low: 130,
        average: 150,
        high: 170,
      },
      riskLevel: 'MODERATE',
    },
    MSFT: {
      symbol: 'MSFT',
      sentiment: 'BULLISH',
      sentimentScore: 82,
      recommendation: 'STRONG BUY',
      technicalIndicators: {
        rsi: 68,
        macd: 'Strong Positive',
        movingAverage: 'Well above 50-day MA',
      },
      keyInsights: [
        {
          type: 'positive',
          title: 'Exceptional Performance',
          description: 'Outstanding performance driven by cloud services and AI integration.',
        },
        {
          type: 'positive',
          title: 'Azure Growth',
          description: 'Azure cloud platform continues to gain market share and revenue.',
        },
        {
          type: 'positive',
          title: 'AI Leadership',
          description: 'Strategic partnership with OpenAI positions company as AI leader.',
        },
        {
          type: 'warning',
          title: 'Valuation Concerns',
          description: 'Current valuation is at premium levels compared to historical averages.',
        },
      ],
      priceTargets: {
        low: 360,
        average: 400,
        high: 440,
      },
      riskLevel: 'LOW',
    },
  };

  return insights[symbol] || insights.AAPL;
};

export function AnalyticalInsightsSection({ symbol }: AnalyticalInsightsProps) {
  const insights = getAnalyticalInsights(symbol);

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'BULLISH':
        return 'bg-green-100 text-green-700';
      case 'BEARISH':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-yellow-100 text-yellow-700';
    }
  };

  const getRecommendationColor = (recommendation: string) => {
    if (recommendation.includes('BUY')) return 'bg-green-600';
    if (recommendation.includes('SELL')) return 'bg-red-600';
    return 'bg-yellow-600';
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'positive':
        return <CheckCircle2 className="w-5 h-5 text-green-600" />;
      case 'warning':
        return <AlertCircle className="w-5 h-5 text-yellow-600" />;
      default:
        return <BarChart className="w-5 h-5 text-blue-600" />;
    }
  };

  return (
    <Card className="p-6 bg-white shadow-sm">
      <div className="flex items-center gap-2 mb-4">
        <Lightbulb className="w-5 h-5 text-blue-600" />
        <h2 className="text-slate-900">Analytical Insights & Recommendations</h2>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {/* Sentiment */}
        <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
          <p className="text-slate-600 text-sm mb-2">Market Sentiment</p>
          <div className="flex items-center justify-between mb-2">
            <Badge className={getSentimentColor(insights.sentiment)}>
              {insights.sentiment}
            </Badge>
            <span className="text-slate-900">{insights.sentimentScore}/100</span>
          </div>
          <Progress value={insights.sentimentScore} className="h-2" />
        </div>

        {/* Recommendation */}
        <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
          <p className="text-slate-600 text-sm mb-2">Recommendation</p>
          <Badge className={`${getRecommendationColor(insights.recommendation)} text-white hover:${getRecommendationColor(insights.recommendation)}`}>
            {insights.recommendation}
          </Badge>
          <p className="text-slate-600 text-sm mt-2">Risk Level: {insights.riskLevel}</p>
        </div>

        {/* Technical Indicators */}
        <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
          <p className="text-slate-600 text-sm mb-2">Technical Indicators</p>
          <div className="space-y-1">
            <p className="text-slate-900 text-sm">RSI: {insights.technicalIndicators.rsi}</p>
            <p className="text-slate-900 text-sm">MACD: {insights.technicalIndicators.macd}</p>
            <p className="text-slate-900 text-sm">{insights.technicalIndicators.movingAverage}</p>
          </div>
        </div>
      </div>

      {/* Key Insights */}
      <div className="mb-6">
        <h3 className="text-slate-900 mb-3">Key Insights</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {insights.keyInsights.map((insight: any, index: number) => (
            <div key={index} className="bg-slate-50 rounded-lg p-4 border border-slate-200">
              <div className="flex items-start gap-3">
                {getInsightIcon(insight.type)}
                <div className="flex-1">
                  <h4 className="text-slate-900 mb-1">{insight.title}</h4>
                  <p className="text-slate-600 text-sm">{insight.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Price Targets */}
      <div>
        <h3 className="text-slate-900 mb-3">Analyst Price Targets</h3>
        <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg p-4 border border-blue-200">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-blue-700 text-sm mb-1">Low Target</p>
              <p className="text-blue-900 text-xl">${insights.priceTargets.low}</p>
            </div>
            <div>
              <p className="text-blue-700 text-sm mb-1">Average Target</p>
              <p className="text-blue-900 text-2xl">${insights.priceTargets.average}</p>
            </div>
            <div>
              <p className="text-blue-700 text-sm mb-1">High Target</p>
              <p className="text-blue-900 text-xl">${insights.priceTargets.high}</p>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
