import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { Calendar, TrendingUp } from 'lucide-react';

interface HistoricalDataProps {
  symbol: string;
}

// Mock data representing Flask API endpoint response
const getHistoricalData = (symbol: string, startDate: string, endDate: string) => {
  // Generate mock historical data
  const data = [];
  const basePrice = symbol === 'AAPL' ? 150 : symbol === 'GOOGL' ? 130 : 350;
  
  for (let i = 0; i < 30; i++) {
    const date = new Date();
    date.setDate(date.getDate() - (29 - i));
    const variance = Math.random() * 20 - 10;
    const price = basePrice + variance + (i * 0.5);
    
    data.push({
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      price: Number(price.toFixed(2)),
      volume: Math.floor(Math.random() * 50000000 + 20000000),
    });
  }
  
  return data;
};

export function HistoricalDataSection({ symbol }: HistoricalDataProps) {
  const [startDate, setStartDate] = useState('2025-12-06');
  const [endDate, setEndDate] = useState('2026-01-05');
  const [historicalData, setHistoricalData] = useState(() => getHistoricalData(symbol, startDate, endDate));

  const handleFetchData = () => {
    const data = getHistoricalData(symbol, startDate, endDate);
    setHistoricalData(data);
  };

  // Update data when symbol changes
  React.useEffect(() => {
    const data = getHistoricalData(symbol, startDate, endDate);
    setHistoricalData(data);
  }, [symbol]);

  return (
    <Card className="p-6 bg-white shadow-sm">
      <div className="flex items-center gap-2 mb-4">
        <Calendar className="w-5 h-5 text-blue-600" />
        <h2 className="text-slate-900">Historical Market Data</h2>
      </div>

      {/* Date Range Selector */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 bg-slate-50 p-4 rounded-lg border border-slate-200">
        <div>
          <Label htmlFor="startDate" className="text-slate-700">Start Date</Label>
          <Input
            id="startDate"
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="endDate" className="text-slate-700">End Date</Label>
          <Input
            id="endDate"
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="mt-1"
          />
        </div>
        <div className="flex items-end">
          <Button onClick={handleFetchData} className="w-full bg-blue-600 hover:bg-blue-700">
            <TrendingUp className="w-4 h-4 mr-2" />
            Fetch Data
          </Button>
        </div>
      </div>

      {/* Price Chart */}
      <div className="mb-6">
        <h3 className="text-slate-900 mb-3">Price Trend</h3>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={historicalData}>
            <defs>
              <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis 
              dataKey="date" 
              stroke="#64748b"
              style={{ fontSize: '12px' }}
            />
            <YAxis 
              stroke="#64748b"
              style={{ fontSize: '12px' }}
              domain={['auto', 'auto']}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#fff', 
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                padding: '8px 12px'
              }}
            />
            <Area 
              type="monotone" 
              dataKey="price" 
              stroke="#3b82f6" 
              strokeWidth={2}
              fill="url(#colorPrice)" 
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Data Table */}
      <div>
        <h3 className="text-slate-900 mb-3">Historical Data Summary</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-100 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 text-left text-slate-900 text-sm">Date</th>
                <th className="px-4 py-3 text-right text-slate-900 text-sm">Price</th>
                <th className="px-4 py-3 text-right text-slate-900 text-sm">Volume</th>
              </tr>
            </thead>
            <tbody>
              {historicalData.slice(-7).reverse().map((item, index) => (
                <tr key={index} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="px-4 py-3 text-slate-900 text-sm">{item.date}</td>
                  <td className="px-4 py-3 text-right text-slate-900">${item.price.toFixed(2)}</td>
                  <td className="px-4 py-3 text-right text-slate-600 text-sm">
                    {item.volume.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </Card>
  );
}
